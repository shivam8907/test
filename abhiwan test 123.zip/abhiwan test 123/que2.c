//program to display the first 10 natural number
#include<stdio.h>
int main()
{
    int i;
    printf("the first 10 natural numbers are\n");
    for(i=1;i<=10;i++)
    {
        printf("%d",i);

    }

}
