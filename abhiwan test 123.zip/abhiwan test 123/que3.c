//sort the given array
#include<stdio.h>
int main()
{
    int a[]=[6,8,1,3,4,77,69];
    int t=0;

    for(int i=0;i<6;i++)
    {
        for(int j=i+1;j<7;j++)
        {
         if(a[i>a[j]
            t=a[i];
            a[i]=a[j];
            a[j]=t;
        )
        }

    }
    for(i=0;i<7;i++)
    {

        printf("%d sort value",t);
    }


}
