//find the second largest elements in the array
#include<stdio.h>
int main()
{
    int a[10]= {2,5,10,4,3,11,5,3,56};
    int i,max1=-1,max2=-2;
    for(i=0;i<10;i++)
    {
        if(a[i]>max1)
        {
            max2=max1;
            max1=a[i];

        }
        else if(max2<a[i])
            max2=a[i];

    }
    printf("second largest element is %d",max2);

}
